﻿using System;
using System.Threading;
// Оголосити тип делегату для поії.
delegate void MyEventHandler();
// Класс, зберігаючий подію
class MyEvent
{
    public event MyEventHandler SomeEvent;
    // Цей метод викликаєтся для запуску події.
    public void OnSomeEvent()
    { if (SomeEvent != null) SomeEvent(); }
}
class EventDemo
{
    // Обробник події.
    static void Handler()
    {
        Console.WriteLine("Сталася подія");
        Console.ReadLine();
    }
    public static void Main()
    {
        MyEvent evt = new MyEvent();
        // Додати метод Handler() у список подій
        evt.SomeEvent += Handler;
        // Запустити подію
        evt.OnSomeEvent();
    }
}