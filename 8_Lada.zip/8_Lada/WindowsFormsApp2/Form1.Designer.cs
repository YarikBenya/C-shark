﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1_baraban = new System.Windows.Forms.Label();
            this.label2_baraban = new System.Windows.Forms.Label();
            this.label3_baraban = new System.Windows.Forms.Label();
            this.timer_stop1 = new System.Windows.Forms.Timer(this.components);
            this.timer_stop2 = new System.Windows.Forms.Timer(this.components);
            this.timer_stop3 = new System.Windows.Forms.Timer(this.components);
            this.button_pysk = new System.Windows.Forms.Button();
            this.button_stavka = new System.Windows.Forms.Button();
            this.label_rahunok = new System.Windows.Forms.Label();
            this.label_stavka = new System.Windows.Forms.Label();
            this.label_sprobu = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.timer_pysk1 = new System.Windows.Forms.Timer(this.components);
            this.timer_pysk2 = new System.Windows.Forms.Timer(this.components);
            this.timer_pysk3 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1_baraban
            // 
            this.label1_baraban.AutoSize = true;
            this.label1_baraban.Font = new System.Drawing.Font("Liquid Crystal", 99.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1_baraban.Location = new System.Drawing.Point(35, 58);
            this.label1_baraban.Name = "label1_baraban";
            this.label1_baraban.Size = new System.Drawing.Size(172, 166);
            this.label1_baraban.TabIndex = 0;
            this.label1_baraban.Text = "0";
            // 
            // label2_baraban
            // 
            this.label2_baraban.AutoSize = true;
            this.label2_baraban.Font = new System.Drawing.Font("Liquid Crystal", 99.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2_baraban.Location = new System.Drawing.Point(189, 58);
            this.label2_baraban.Name = "label2_baraban";
            this.label2_baraban.Size = new System.Drawing.Size(172, 166);
            this.label2_baraban.TabIndex = 1;
            this.label2_baraban.Text = "0";
            // 
            // label3_baraban
            // 
            this.label3_baraban.AutoSize = true;
            this.label3_baraban.Font = new System.Drawing.Font("Liquid Crystal", 99.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3_baraban.Location = new System.Drawing.Point(343, 58);
            this.label3_baraban.Name = "label3_baraban";
            this.label3_baraban.Size = new System.Drawing.Size(172, 166);
            this.label3_baraban.TabIndex = 2;
            this.label3_baraban.Text = "0";
            // 
            // timer_stop1
            // 
            this.timer_stop1.Interval = 1000;
            this.timer_stop1.Tick += new System.EventHandler(this.timer_stop1_Tick);
            // 
            // timer_stop2
            // 
            this.timer_stop2.Interval = 2000;
            this.timer_stop2.Tick += new System.EventHandler(this.timer_stop2_Tick);
            // 
            // timer_stop3
            // 
            this.timer_stop3.Interval = 3500;
            this.timer_stop3.Tick += new System.EventHandler(this.timer_stop3_Tick);
            // 
            // button_pysk
            // 
            this.button_pysk.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_pysk.ForeColor = System.Drawing.Color.Green;
            this.button_pysk.Location = new System.Drawing.Point(12, 220);
            this.button_pysk.Name = "button_pysk";
            this.button_pysk.Size = new System.Drawing.Size(515, 84);
            this.button_pysk.TabIndex = 3;
            this.button_pysk.Text = "Крутити барабан!";
            this.button_pysk.UseVisualStyleBackColor = true;
            this.button_pysk.Visible = false;
            this.button_pysk.Click += new System.EventHandler(this.button_pysk_Click_1);
            // 
            // button_stavka
            // 
            this.button_stavka.Font = new System.Drawing.Font("Arial", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_stavka.ForeColor = System.Drawing.Color.DarkOrange;
            this.button_stavka.Location = new System.Drawing.Point(12, 311);
            this.button_stavka.Name = "button_stavka";
            this.button_stavka.Size = new System.Drawing.Size(255, 143);
            this.button_stavka.TabIndex = 4;
            this.button_stavka.Text = "Внести ставку";
            this.button_stavka.UseVisualStyleBackColor = true;
            this.button_stavka.Click += new System.EventHandler(this.button_stavka_Click_1);
            // 
            // label_rahunok
            // 
            this.label_rahunok.AutoSize = true;
            this.label_rahunok.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_rahunok.Location = new System.Drawing.Point(329, 9);
            this.label_rahunok.Name = "label_rahunok";
            this.label_rahunok.Size = new System.Drawing.Size(198, 32);
            this.label_rahunok.TabIndex = 5;
            this.label_rahunok.Text = "Рахунок: 100 ₴";
            // 
            // label_stavka
            // 
            this.label_stavka.AutoSize = true;
            this.label_stavka.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_stavka.Location = new System.Drawing.Point(273, 343);
            this.label_stavka.Name = "label_stavka";
            this.label_stavka.Size = new System.Drawing.Size(157, 31);
            this.label_stavka.TabIndex = 6;
            this.label_stavka.Text = "Ваша ставка:";
            // 
            // label_sprobu
            // 
            this.label_sprobu.AutoSize = true;
            this.label_sprobu.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_sprobu.Location = new System.Drawing.Point(273, 399);
            this.label_sprobu.Name = "label_sprobu";
            this.label_sprobu.Size = new System.Drawing.Size(252, 31);
            this.label_sprobu.TabIndex = 7;
            this.label_sprobu.Text = "Залишилось спроб: 0";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.numericUpDown1.Increment = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numericUpDown1.Location = new System.Drawing.Point(436, 341);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            75,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(49, 38);
            this.numericUpDown1.TabIndex = 8;
            this.numericUpDown1.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // timer_pysk1
            // 
            this.timer_pysk1.Tick += new System.EventHandler(this.timer_pysk1_Tick_1);
            // 
            // timer_pysk2
            // 
            this.timer_pysk2.Tick += new System.EventHandler(this.timer_pysk2_Tick_1);
            // 
            // timer_pysk3
            // 
            this.timer_pysk3.Tick += new System.EventHandler(this.timer_pysk3_Tick_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(539, 466);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.label_sprobu);
            this.Controls.Add(this.label_stavka);
            this.Controls.Add(this.label_rahunok);
            this.Controls.Add(this.button_stavka);
            this.Controls.Add(this.button_pysk);
            this.Controls.Add(this.label3_baraban);
            this.Controls.Add(this.label2_baraban);
            this.Controls.Add(this.label1_baraban);
            this.Name = "Form1";
            this.Text = "Grand Theft Auto VI";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1_baraban;
        private System.Windows.Forms.Label label2_baraban;
        private System.Windows.Forms.Label label3_baraban;
        private System.Windows.Forms.Timer timer_stop1;
        private System.Windows.Forms.Timer timer_stop2;
        private System.Windows.Forms.Timer timer_stop3;
        private System.Windows.Forms.Button button_pysk;
        private System.Windows.Forms.Button button_stavka;
        private System.Windows.Forms.Label label_rahunok;
        private System.Windows.Forms.Label label_stavka;
        private System.Windows.Forms.Label label_sprobu;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Timer timer_pysk1;
        private System.Windows.Forms.Timer timer_pysk2;
        private System.Windows.Forms.Timer timer_pysk3;
    }
}

