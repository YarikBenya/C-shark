﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{


    public partial class Form1 : Form
    {

        int balance = 100; //Исходный баланс.
        int counter_money = 0; //Текущий ставка.
        int counter_try = 0; //Счетчик попыток.
        int win_money = 0; //Выигранные деньги.
        bool IsActive = true; //Активность кнопки "Погнали!"
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void timer_pysk1_Tick_1(object sender, EventArgs e)
        {
            Random random = new Random();
            int dvg = random.Next(8);
            label1_baraban.Text = dvg.ToString();
        }

        private void timer_pysk2_Tick_1(object sender, EventArgs e)
        {
            Random random = new Random();
            int dvg = random.Next(8);
            label2_baraban.Text = dvg.ToString();
        }

        private void timer_pysk3_Tick_1(object sender, EventArgs e)
        {
            Random random = new Random();
            int dvg = random.Next(8);
            label3_baraban.Text = dvg.ToString();
        }

        private void Win_Money()
        {
            if (label1_baraban.Text == "0" && label2_baraban.Text == "0" && label3_baraban.Text == "0") Upd_Win_Money(17);
            if (label1_baraban.Text == "1" && label2_baraban.Text == "1" && label3_baraban.Text == "1") Upd_Win_Money(10);
            if (label1_baraban.Text == "2" && label2_baraban.Text == "2" && label3_baraban.Text == "2") Upd_Win_Money(11);
            if (label1_baraban.Text == "3" && label2_baraban.Text == "3" && label3_baraban.Text == "3") Upd_Win_Money(12);
            if (label1_baraban.Text == "4" && label2_baraban.Text == "4" && label3_baraban.Text == "4") Upd_Win_Money(13);
            if (label1_baraban.Text == "5" && label2_baraban.Text == "5" && label3_baraban.Text == "5") Upd_Win_Money(14);
            if (label1_baraban.Text == "6" && label2_baraban.Text == "6" && label3_baraban.Text == "6") Upd_Win_Money(15);
            if (label1_baraban.Text == "7" && label2_baraban.Text == "7" && label3_baraban.Text == "7") Upd_Win_Money(20);
            if ((label1_baraban.Text == "0" && label2_baraban.Text == "0") || (label2_baraban.Text == "0" && label3_baraban.Text == "0")) Upd_Win_Money(7);
            if ((label1_baraban.Text == "1" && label2_baraban.Text == "1") || (label2_baraban.Text == "1" && label3_baraban.Text == "1")) Upd_Win_Money(1);
            if ((label1_baraban.Text == "2" && label2_baraban.Text == "2") || (label2_baraban.Text == "2" && label3_baraban.Text == "2")) Upd_Win_Money(2);
            if ((label1_baraban.Text == "3" && label2_baraban.Text == "3") || (label2_baraban.Text == "3" && label3_baraban.Text == "3")) Upd_Win_Money(3);
            if ((label1_baraban.Text == "4" && label2_baraban.Text == "4") || (label2_baraban.Text == "4" && label3_baraban.Text == "4")) Upd_Win_Money(4);
            if ((label1_baraban.Text == "5" && label2_baraban.Text == "5") || (label2_baraban.Text == "5" && label3_baraban.Text == "5")) Upd_Win_Money(5);
            if ((label1_baraban.Text == "6" && label2_baraban.Text == "6") || (label2_baraban.Text == "6" && label3_baraban.Text == "6")) Upd_Win_Money(6);
            if ((label1_baraban.Text == "7" && label2_baraban.Text == "7") || (label2_baraban.Text == "7" && label3_baraban.Text == "7")) Upd_Win_Money(10);
        }
        private void Upd_Win_Money(int number)
        {
            win_money = counter_money * number; 
            DialogResult result = MessageBox.Show("Ти виграв: ₴ " + win_money, "Вітаю!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            balance = balance + win_money; 
            label_rahunok.Text = "Рахунок: ₴" + balance; 
            button_pysk.Enabled = false; 
            button_stavka.Enabled = true; 
            IsActive = false; 
            if (result == DialogResult.OK)
            {
                MessageBox.Show("Давай нову ставку!", "Нова гра", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                label_sprobu.Text = "Залишилось спроб: 0"; // Скидываем оставшиеся попытки.
            }
        }

        private void Init_Counter(decimal counter)
        {
            counter_money = Convert.ToInt32(counter); 
            balance = balance - counter_money; 
            label_rahunok.Text = "Рахунок: ₴" + balance; 
            counter_try = 5; // Зачисляем 5 попыток.
            label_sprobu.Text = "Залишилось спроб: " + counter_try; 
        }

        private void timer_stop1_Tick(object sender, EventArgs e)
        {
            timer_pysk1.Enabled = false;
            timer_stop1.Enabled = false;

        }

        private void timer_stop2_Tick(object sender, EventArgs e)
        {
            timer_pysk2.Enabled = false;
            timer_stop2.Enabled = false;
        }

        private void timer_stop3_Tick(object sender, EventArgs e)
        {
            counter_try--;
            timer_pysk3.Enabled = false;
            timer_stop3.Enabled = false;
            Win_Money();
            if (IsActive)
            {
                if (counter_try != 0)
                {
                    label_sprobu.Text = "Залишилось спроб: " + counter_try;
                    button_pysk.Enabled = true;
                }
                else
                {
                    label_sprobu.Text = "Залишилось спроб:" + counter_try;
                    MessageBox.Show("Давай нову ставку!", "Спроби закінчились...", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    button_stavka.Enabled = true;
                }
            }
        }

        private void button_stavka_Click_1(object sender, EventArgs e)
        {
            Init_Counter(numericUpDown1.Value); //Вызываем инициализирующий метод
            button_pysk.Visible = true; // Открываем доступ к кнопке «Погнали!»
            button_stavka.Enabled = false; //ЗАкрываем доступ к кнопке «Сделать ставку».
        }
        private void button_pysk_Click_1(object sender, EventArgs e)
        {
            timer_pysk1.Enabled = true;
            timer_pysk2.Enabled = true;
            timer_pysk3.Enabled = true;
            timer_stop1.Enabled = true;
            timer_stop2.Enabled = true;
            timer_stop3.Enabled = true;
            IsActive = true;
            button_pysk.Visible = false;
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            MessageBox.Show("By Yaroslav Binkovsky", "END...", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
