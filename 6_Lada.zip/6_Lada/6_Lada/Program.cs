﻿using System;
using System.Text;
using System.Threading.Tasks;

namespace _6_Lada
{
    class Program
    {
        static void  main (string[] args)
        {
        }

        class DemoTask
        {
            // A method to be run as a task.
            static void MyTask()
            {
                Console.WriteLine("MyTask() #" + Task.CurrentId +
               " starting");
                for (int count = 0; count < 10; count++)
                {
                    Console.WriteLine("In MyTask() #" + Task.CurrentId +
                    ", count is " + count);
                }
                Console.WriteLine("MyTask #" + Task.CurrentId + " terminating");
            }
            static void Main()
            {
                Console.WriteLine("Main thread starting.");
                // Construct two tasks.
                Task tsk = new Task(MyTask);
                Task tsk2 = new Task(MyTask);
                // Run the tasks.
                tsk.Start();
                tsk2.Start();
                Console.WriteLine("Task ID for tsk is " + tsk.Id);
                Console.WriteLine("Task ID for tsk2 is " + tsk2.Id);
                // Keep Main() alive until the other tasks finish.
                for (int i = 0; i < 60; i++)
                {
                    Console.Write(".");
                }
                Console.WriteLine("Main thread ending.");
                Console.ReadKey();
            }
        }
    }
}
